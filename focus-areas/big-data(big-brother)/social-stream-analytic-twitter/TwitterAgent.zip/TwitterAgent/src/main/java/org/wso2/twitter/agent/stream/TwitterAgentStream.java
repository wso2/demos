package org.wso2.twitter.agent.stream;

import org.wso2.carbon.databridge.agent.thrift.Agent;
import org.wso2.carbon.databridge.agent.thrift.AsyncDataPublisher;
import org.wso2.carbon.databridge.agent.thrift.conf.AgentConfiguration;
import twitter4j.*;

import java.util.ArrayList;
import java.util.Arrays;

public class TwitterAgentStream {

    public static void main(String[] args) throws InterruptedException {

        //Subscribing tags
        args = new String[]{"#cloud"};

        //Configuring Agent
        AgentConfiguration agentConfiguration = new AgentConfiguration();
        agentConfiguration.setTrustStorePassword("/Users/suho/wso2/dev/twitter-sample/wso2cep-3.0.0/repository/" +
                "resources/security/client-truststore.jks");
        agentConfiguration.setTrustStore("wso2carbon");

        Agent agent = new Agent(agentConfiguration);

        //New Data publisher to BAM
        final AsyncDataPublisher asyncDataPublisher = new AsyncDataPublisher("tcp://localhost:7611",
                "admin", "admin", agent);

        //Defining the Stream
        String STREAM_NAME = "twitter_data_stream";
        String VERSION = "1.0.0";
        String streamDefinition = "{" +
                " 'name':'" + STREAM_NAME + "'," +
                " 'version':'" + VERSION + "'," +
                " 'nickName': 'Twitter_Data_Stream'," +
                " 'description': 'Stream of twitter data'," +
                " 'payloadData':[" +
                " {'name':'createdAt','type':'LONG'}," +
                " {'name':'user','type':'STRING'}," +
                " {'name':'tweet','type':'STRING'}" +
                " ]" +
                "}";
        asyncDataPublisher.addStreamDefinition(streamDefinition, STREAM_NAME, VERSION);

        Thread.sleep(2000);

        //Creating the Twitter Stream Listener based on Twitter4J
        StatusListener listener = new TwitterStatusListener(asyncDataPublisher, STREAM_NAME, VERSION);

        TwitterStream twitterStream = new TwitterStreamFactory().getInstance();
        twitterStream.addListener(listener);
        ArrayList<Long> follow = new ArrayList<Long>();
        ArrayList<String> track = new ArrayList<String>();
        for (String arg : args) {
            if (isNumericalArgument(arg)) {
                for (String id : arg.split(",")) {
                    follow.add(Long.parseLong(id));
                }
            } else {
                track.addAll(Arrays.asList(arg.split(",")));
            }
        }
        long[] followArray = new long[follow.size()];
        for (int i = 0; i < follow.size(); i++) {
            followArray[i] = follow.get(i);
        }
        String[] trackArray = track.toArray(new String[track.size()]);

        twitterStream.filter(new FilterQuery(0, followArray, trackArray));
    }

    private static boolean isNumericalArgument(String argument) {
        String args[] = argument.split(",");
        boolean isNumericalArgument = true;
        for (String arg : args) {
            try {
                Integer.parseInt(arg);
            } catch (NumberFormatException nfe) {
                isNumericalArgument = false;
                break;
            }
        }
        return isNumericalArgument;
    }

}
