package org.wso2.twitter.agent.stream;

import org.wso2.carbon.databridge.agent.thrift.AsyncDataPublisher;
import org.wso2.carbon.databridge.agent.thrift.exception.AgentException;
import twitter4j.StallWarning;
import twitter4j.Status;
import twitter4j.StatusDeletionNotice;
import twitter4j.StatusListener;

class TwitterStatusListener implements StatusListener {
    AsyncDataPublisher asyncDataPublisher;
    private String streamName;
    private String version;


    public TwitterStatusListener(AsyncDataPublisher asyncDataPublisher, String streamName, String version) {
        this.asyncDataPublisher = asyncDataPublisher;
        this.streamName = streamName;
        this.version = version;
    }

    public void onStatus(Status status) {
        System.out.println("@" + status.getUser().getScreenName() + " - " + status.getText());
        try {
            asyncDataPublisher.publish(streamName, version, System.currentTimeMillis(), null, null, new Object[]{status.getCreatedAt().getTime(), status.getUser().getScreenName(), status.getText()});
        } catch (AgentException e) {
            e.printStackTrace();
        }
    }

    public void onDeletionNotice(StatusDeletionNotice statusDeletionNotice) {
    }

    public void onTrackLimitationNotice(int numberOfLimitedStatuses) {
    }

    public void onScrubGeo(long userId, long upToStatusId) {
    }

    public void onStallWarning(StallWarning warning) {
    }

    public void onException(Exception ex) {
        ex.printStackTrace();
    }
}
